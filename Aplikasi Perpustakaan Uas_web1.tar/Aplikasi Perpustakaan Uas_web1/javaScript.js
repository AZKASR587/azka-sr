function validasiForm() {
    // Ambil nilai input
    const nama = document.getElementById('nama').value;
    const jumlah = document.getElementById('jumlah').value;
    const kategori = document.getElementById('kategori').value;

    // 9. Validasi Input
    if (nama === "" || jumlah === "" || kategori === "") {
        alert("Semua kolom harus diisi!");
        return;
    }

    // Jika valid, masukkan ke tabel
    const table = document.getElementById('listTransaksi');
    const row = table.insertRow();
    
    row.innerHTML = `
        <td>${nama}</td>
        <td>${jumlah}</td>
        <td>${kategori}</td>
    `;

    // Reset form setelah simpan
    document.getElementById('nama').value = "";
    document.getElementById('jumlah').value = "";
    document.getElementById('kategori').value = "";
    
    alert("Data berhasil disimpan!");
}